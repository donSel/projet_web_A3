<?php
//Author: Prenom NOM
//Login : etuXXX
//Groupe: ISEN X GROUPE Y
//Annee:

// Constantes pour la connexion BDD
define ('DB_USER', "etu740");
define ('DB_PASSWORD', "mkdxuhnf");
define ('DB_NAME', "etu740");
define ('DB_SERVER', "127.0.0.1"); # ou 51.210.13.26
define ('DB_PORT', "3306");
?>
